# v7 > 2022-10-29 2:43pm
https://universe.roboflow.com/v7-o6dg3/v7-2s66t

Provided by a Roboflow user
License: CC BY 4.0

